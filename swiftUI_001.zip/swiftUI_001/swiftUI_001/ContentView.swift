//
//  ContentView.swift
//  swiftUI_001
//
//  Created by SMH on 19/06/24.
//

import SwiftUI

// MARK: - ContentView
// This view serves as the main interface, combining multiple animations and interactive elements.
struct ContentView: View {
    // State variables to control various animations and interactive elements
    @State private var isSpinning = false
    @State private var progress: CGFloat = 0.0
    @State private var isLoading = true
    
    var body: some View {
        ScrollView {
            VStack(spacing: 40) {
                
                // MARK: - Loading Animation
                VStack {
                    Text("Loading Animation")
                        .font(.headline)
                    LoadingView()
                }
                
                // MARK: - Progress Bar Animation
                VStack {
                    Text("Progress Bar Animation")
                        .font(.headline)
                    ProgressBarView(progress: $progress)
                    Button(action: {
                        // Toggle the progress with animation
                        withAnimation {
                            progress = progress == 1.0 ? 0.0 : 1.0
                        }
                    }) {
                        Text("Toggle Progress")
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }
                }
                
                // MARK: - Pulse Animation
                VStack {
                    Text("Pulse Animation")
                        .font(.headline)
                    PulseView()
                }
                
                // MARK: - Shimmer Effect
                VStack {
                    Text("Shimmer Effect")
                        .font(.headline)
                    ShimmerView()
                }
                
                // MARK: - Custom Interactive Spinner
                VStack {
                    Text("Custom Interactive Spinner")
                        .font(.headline)
                    CustomSpinnerView(isSpinning: $isSpinning)
                    Button(action: {
                        // Toggle spinner state
                        isSpinning.toggle()
                    }) {
                        Text(isSpinning ? "Stop Spinner" : "Start Spinner")
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }
                }
                
                // MARK: - Loading Skeleton for List
                VStack {
                    Text("Loading Skeleton")
                        .font(.headline)
                    LoadingSkeletonView(isLoading: $isLoading)
                    Button(action: {
                        // Toggle loading state
                        isLoading.toggle()
                    }) {
                        Text(isLoading ? "Show Content" : "Show Skeleton")
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }
                }
            }
            .padding()
        }
    }
}

// MARK: - Previews
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

// MARK: - LoadingView
// A simple spinning circle animation to indicate loading.
struct LoadingView: View {
    @State private var isAnimating = false
    
    var body: some View {
        Circle()
            .trim(from: 0.0, to: 0.8) // Create a circular arc
            .stroke(Color.blue, lineWidth: 8) // Style the arc
            .frame(width: 50, height: 50) // Set the size of the arc
            .rotationEffect(Angle(degrees: isAnimating ? 360 : 0)) // Rotate the arc
            .onAppear {
                // Start the animation when the view appears
                withAnimation(Animation.linear(duration: 1).repeatForever(autoreverses: false)) {
                    isAnimating = true
                }
            }
    }
}

// MARK: - ProgressBarView
// A horizontal progress bar with animated progress.
struct ProgressBarView: View {
    @Binding var progress: CGFloat // Bind progress to a state variable in the parent view
    
    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .leading) {
                Rectangle()
                    .frame(width: geometry.size.width, height: 10) // Background bar
                    .opacity(0.3)
                    .foregroundColor(Color(UIColor.systemTeal))
                
                Rectangle()
                    .frame(width: min(progress * geometry.size.width, geometry.size.width), height: 10) // Progress bar
                    .foregroundColor(Color(UIColor.systemBlue))
            }
            .cornerRadius(5)
        }
        .frame(height: 10)
    }
}

// MARK: - PulseView
// A pulsing circle animation.
struct PulseView: View {
    @State private var pulse = false
    
    var body: some View {
        Circle()
            .fill(Color.blue)
            .frame(width: 100, height: 100) // Circle size
            .scaleEffect(pulse ? 1.2 : 1.0) // Scale the circle
            .onAppear {
                // Start the pulse animation when the view appears
                withAnimation(Animation.easeInOut(duration: 1).repeatForever(autoreverses: true)) {
                    pulse = true
                }
            }
    }
}

// MARK: - ShimmerView
// A shimmering text effect.
struct ShimmerView: View {
    @State private var shimmer = false
    
    var body: some View {
        Text("Shimmering Text")
            .font(.largeTitle)
            .foregroundColor(.gray)
            .overlay(
                Rectangle()
                    .fill(LinearGradient(gradient: Gradient(colors: [.clear, .white, .clear]), startPoint: .topLeading, endPoint: .bottomTrailing)) // Create gradient
                    .rotationEffect(Angle(degrees: 30)) // Rotate the gradient
                    .offset(x: shimmer ? 300 : -300) // Move the gradient
                    .onAppear {
                        // Start the shimmer animation when the view appears
                        withAnimation(Animation.linear(duration: 1.5).repeatForever(autoreverses: false)) {
                            shimmer = true
                        }
                    }
            )
    }
}

// MARK: - CustomSpinnerView
// A custom spinner that can be controlled by the user.
struct CustomSpinnerView: View {
    @Binding var isSpinning: Bool
    @State private var rotation: Double = 0
    
    var body: some View {
        Circle()
            .trim(from: 0.2, to: 1) // Create a partial circle
            .stroke(Color.blue, lineWidth: 8) // Style the circle
            .frame(width: 50, height: 50) // Set the size of the circle
            .rotationEffect(Angle(degrees: rotation)) // Rotate the circle
            .animation(isSpinning ? Animation.linear(duration: 1).repeatForever(autoreverses: false) : .default, value: rotation) // Animation control
            .onAppear {
                if isSpinning {
                    rotation = 360
                }
            }
            .onChange(of: isSpinning) { newValue in
                if newValue {
                    rotation = 360
                } else {
                    rotation = 0
                }
            }
    }
}

// MARK: - LoadingSkeletonView
// A loading skeleton for a list, to be displayed while data is being fetched.
struct LoadingSkeletonView: View {
    @Binding var isLoading: Bool
    let data = ["Item 1", "Item 2", "Item 3", "Item 4"]
    
    var body: some View {
        List {
            if isLoading {
                // Show skeleton rows when loading
                ForEach(0..<5) { _ in
                    SkeletonRow()
                }
            } else {
                // Show data when not loading
                ForEach(data, id: \.self) { item in
                    Text(item)
                }
            }
        }
    }
}

// MARK: - SkeletonRow
// A single skeleton row with shimmering effect.
struct SkeletonRow: View {
    var body: some View {
        HStack {
            Circle()
                .fill(Color.gray.opacity(0.5)) // Placeholder circle
                .frame(width: 50, height: 50)
            VStack(alignment: .leading) {
                Rectangle()
                    .fill(Color.gray.opacity(0.5)) // Placeholder line
                    .frame(height: 20)
                Rectangle()
                    .fill(Color.gray.opacity(0.5)) // Placeholder line
                    .frame(height: 20)
                    .padding(.top, 4)
            }
            .shimmering() // Apply shimmering effect
        }
        .padding(.vertical, 8)
    }
}

// MARK: - View Extension for Shimmer Effect
extension View {
    func shimmering() -> some View {
        self.overlay(
            GeometryReader { geometry in
                Rectangle()
                    .fill(LinearGradient(gradient: Gradient(colors: [.clear, Color.white.opacity(0.4), .clear]), startPoint: .topLeading, endPoint: .bottomTrailing))
                    .rotationEffect(Angle(degrees: 30))
                    .offset(x: -geometry.size.width)
                    .animation(Animation.linear(duration: 1.5).repeatForever(autoreverses: false))
            }
        )
    }
}

//
//  swiftUI_001App.swift
//  swiftUI_001
//
//  Created by SMH on 19/06/24.
//

import SwiftUI

@main
struct swiftUI_001App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
